# Jarvis - Personal AI Voice Assistant

Jarvis is an Android application inspired by Iron Man's personal AI assistant. It's designed to be a modular, clean, and beginner-friendly project that showcases how to build a voice assistant using official Android APIs.

## App Workflow

The application's workflow is designed to be straightforward and event-driven:

1.  **Activation**: The user launches the app, which opens the `HomeActivity`. To start interacting with Jarvis, the user presses the "Listen" button.
2.  **Listening**: Pressing the button activates the `SpeechEngine`, which uses Android's built-in `SpeechRecognizer` to listen for voice commands in both English and Hindi.
3.  **Command Recognition**: Once the user finishes speaking, the `SpeechEngine` processes the audio and converts it into text.
4.  **Routing**: The recognized text command is then passed to the `CommandRouter`.
5.  **Intent Understanding**:
    *   For simple, predefined commands (e.g., "open camera", "play music"), the `CommandRouter` uses basic keyword matching to identify the user's intent.
    *   For more complex or ambiguous queries, the `CommandRouter` sends the command to the `JarvisBrain`.
6.  **AI-Powered Brain**: The `JarvisBrain` utilizes the Gemini API to perform natural language understanding. It interprets the user's intent, summarizes information, or formulates suggestions, and then sends a structured response back to the `CommandRouter`.
7.  **Feature Execution**: Based on the determined intent, the `CommandRouter` delegates the task to the appropriate feature module (e.g., `TaskManager`, `Messenger`, `Downloader`).
8.  **Feedback**: The app provides feedback to the user, either through voice using the `TextToSpeech` engine in the `SpeechEngine`, or by updating the UI on the `HomeActivity` or `DashboardActivity`.
9.  **Overlay UI**: For certain features like Camera Search or for persistent interaction, the `FloatingHUD` service can be started, which displays an overlay on top of other apps.

## How to Place Your Gemini API Key

To enable the AI capabilities of Jarvis, you need to add your own Gemini API key using a secure method.

1.  In the root directory of the project, create a new file named `local.properties`.
2.  Add the following line to the `local.properties` file, replacing `"YOUR_API_KEY"` with your actual Gemini API key:
    ```
    GEMINI_API_KEY="YOUR_API_KEY"
    ```
3.  The `app/build.gradle` file is already configured to read this key and make it available to the app at build time. The `local.properties` file is included in the `.gitignore` file, so your API key will not be committed to version control.

This is a much more secure method than hardcoding the key in the source code.

## Android Limitations (Honest Overview)

Building a Jarvis-like assistant on a standard Android OS has several limitations due to security and design constraints. This app uses official APIs only and does not rely on rooting or other hacks. Here's what that means in practice:

*   **No "Always-On" Hotword**: Modern Android versions heavily restrict background processes to conserve battery. A true "Hey Jarvis" hotword detection that is always listening is not reliably possible without running a persistent foreground service, which is battery-intensive and highly likely to be killed by the OS. The button-based activation in this app is a more practical and battery-friendly approach.
*   **Accessibility Service is Required for UI Control**: To perform system-level navigation like "back", "home", or "recents", the app would need to be enabled as an Accessibility Service. This is a very powerful permission that the user must grant manually from deep within the system settings. It allows the app to read the screen and perform gestures, which can be a security concern for users. This app includes the placeholder logic but would require the user to grant this permission.
*   **Limited App Control (No Root)**: Without root access, Jarvis cannot silently install apps, toggle hardware like GPS, or interact with the internals of other applications. It can open apps, but it cannot control them (e.g., "send a WhatsApp message to John"). The `Messenger` feature works by creating standard Android intents (e.g., `Intent.ACTION_SEND`), which pre-fills the data but still requires the user to press the "send" button within the target app (WhatsApp, Telegram, etc.).
*   **Overlay Permission for HUD**: To display the `FloatingHUD` on top of other apps, the user must manually grant the "Draw over other apps" (`SYSTEM_ALERT_WINDOW`) permission. This is another manual step for the user and some phone manufacturers (like Xiaomi or Huawei) have additional restrictions that can make it difficult to get this permission.
*   **Simplified App Recognition**: The `CommandRouter`'s logic for opening apps relies on a simple, hardcoded map of app names to package names. A real-world implementation would require a much more sophisticated system to dynamically find the correct package name for any installed app on the user's device.

This project aims to be a realistic implementation of a personal assistant within the boundaries of the official Android SDK, providing a solid foundation for anyone looking to build similar applications.
