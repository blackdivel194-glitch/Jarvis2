package com.jarvis.app.features;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

public class Messenger {

    private final Context context;

    public Messenger(Context context) {
        this.context = context;
    }

    public void sendMessage(String phoneNumber, String message) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("sms:" + phoneNumber));
        intent.putExtra("sms_body", message);
        context.startActivity(intent);
    }

    public void shareText(String text, String packageName) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT, text);
        if (packageName != null) {
            intent.setPackage(packageName);
        }
        context.startActivity(Intent.createChooser(intent, "Share text to"));
    }

    public void shareMedia(Uri uri, String type, String packageName) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType(type);
        intent.putExtra(Intent.EXTRA_STREAM, uri);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        if (packageName != null) {
            intent.setPackage(packageName);
        }
        context.startActivity(Intent.createChooser(intent, "Share media to"));
    }
}
