package com.jarvis.app.core;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.util.Log;

import java.util.ArrayList;
import java.util.Locale;

public class SpeechEngine {

    private static final String TAG = "SpeechEngine";
    private static final long LISTENING_TIMEOUT = 3 * 60 * 1000; // 3 minutes

    private final SpeechRecognizer speechRecognizer;
    private final TextToSpeech textToSpeech;
    private final SpeechCallback speechCallback;
    private final Context context;
    private boolean isListening = false;
    private final Handler timeoutHandler = new Handler();

    public interface SpeechCallback {
        void onSpeechResult(String result);
        void onSpeechError(String errorMessage);
        void onListeningStatusChanged(boolean isListening);
    }

    public SpeechEngine(Context context, SpeechCallback callback) {
        this.context = context;
        this.speechCallback = callback;
        this.speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context);
        this.textToSpeech = new TextToSpeech(context, status -> {
            if (status != TextToSpeech.SUCCESS) {
                Log.e(TAG, "TTS initialization failed");
            } else {
                textToSpeech.setLanguage(Locale.US);
            }
        });

        setupSpeechRecognizer();
    }

    private void setupSpeechRecognizer() {
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) {
                    speechCallback.onSpeechResult(matches.get(0));
                }
                // Restart listening
                if (isListening) {
                    startListeningInternal();
                }
            }

            @Override
            public void onError(int error) {
                // Ignore certain errors and restart listening
                if (isListening && (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT)) {
                    startListeningInternal();
                } else {
                    speechCallback.onSpeechError("Speech recognition error: " + error);
                    stopListening();
                }
            }

            @Override
            public void onReadyForSpeech(Bundle params) {}
            @Override
            public void onBeginningOfSpeech() {}
            @Override
            public void onRmsChanged(float rmsdB) {}
            @Override
            public void onBufferReceived(byte[] buffer) {}
            @Override
            public void onEndOfSpeech() {}
            @Override
            public void onPartialResults(Bundle partialResults) {}
            @Override
            public void onEvent(int eventType, Bundle params) {}
        });
    }

    private void startListeningInternal() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Listening...");
        speechRecognizer.startListening(intent);
    }

    public void startListening() {
        if (!isListening) {
            isListening = true;
            speechCallback.onListeningStatusChanged(true);
            startListeningInternal();
            // Start a timeout to stop listening after a while
            timeoutHandler.postDelayed(this::stopListening, LISTENING_TIMEOUT);
        }
    }

    public void stopListening() {
        if (isListening) {
            isListening = false;
            speechCallback.onListeningStatusChanged(false);
            speechRecognizer.stopListening();
            timeoutHandler.removeCallbacksAndMessages(null);
        }
    }

    public void cancelListening() {
        stopListening();
    }

    public void speak(String text) {
        textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
    }

    public void shutdown() {
        speechRecognizer.destroy();
        textToSpeech.stop();
        textToSpeech.shutdown();
    }
}
