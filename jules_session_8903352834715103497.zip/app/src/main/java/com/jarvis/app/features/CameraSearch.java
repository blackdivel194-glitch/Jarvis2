package com.jarvis.app.features;

import android.content.Context;

public class CameraSearch {

    private final Context context;

    public CameraSearch(Context context) {
        this.context = context;
    }

    public void startCameraSearch() {
        // TODO: Implement camera preview
        // TODO: Implement object detection (placeholder logic)
        // TODO: Implement floating window to display object information
    }
}
