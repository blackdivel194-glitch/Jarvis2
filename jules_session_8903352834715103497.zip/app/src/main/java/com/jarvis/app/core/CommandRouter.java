package com.jarvis.app.core;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Log;
import com.jarvis.app.features.NotesManager;
import com.jarvis.app.features.TaskManager;
import com.jarvis.app.ui.DashboardActivity;

public class CommandRouter {

    private static final String TAG = "CommandRouter";
    private final Context context;
    private final JarvisBrain jarvisBrain;
    private final TaskManager taskManager;
    private final NotesManager notesManager;
    private final SpeechEngine speechEngine;

    public interface CommandCallback {
        void onCommandProcessed(String response);
    }

    public CommandRouter(Context context, JarvisBrain jarvisBrain, SpeechEngine speechEngine) {
        this.context = context;
        this.jarvisBrain = jarvisBrain;
        this.speechEngine = speechEngine;
        this.taskManager = new TaskManager(context);
        this.notesManager = new NotesManager(context);
    }

    public void routeCommand(String command, CommandCallback callback) {
        String lowerCaseCommand = command.toLowerCase();

        if (lowerCaseCommand.equals("cancel")) {
            speechEngine.cancelListening();
            callback.onCommandProcessed("Listening canceled.");
        } else if (lowerCaseCommand.startsWith("open")) {
            String response = openApp(command);
            callback.onCommandProcessed(response);
        } else if (lowerCaseCommand.startsWith("add task")) {
            String task = command.substring("add task".length()).trim();
            String response = taskManager.addTask(task);
            callback.onCommandProcessed(response);
        } else if (lowerCaseCommand.startsWith("show tasks")) {
            String response = taskManager.showTasks();
            callback.onCommandProcessed(response);
        } else if (lowerCaseCommand.startsWith("make note")) {
            // This is a simplified implementation. A real app would need a more robust way to parse the title and content.
            String noteContent = command.substring("make note".length()).trim();
            String[] noteParts = noteContent.split("content");
            String title = noteParts[0].replace("title", "").trim();
            String content = noteParts.length > 1 ? noteParts[1].trim() : "";
            String response = notesManager.createNote(title, content);
            callback.onCommandProcessed(response);
        } else if (lowerCaseCommand.startsWith("show notes")) {
            String response = notesManager.showNotes();
            callback.onCommandProcessed(response);
        } else if (lowerCaseCommand.equals("update me")) {
            context.startActivity(new Intent(context, DashboardActivity.class));
            callback.onCommandProcessed("Here is your daily update.");
        } else if (lowerCaseCommand.contains("back")) {
            // Requires Accessibility Service
            Log.d(TAG, "Executing 'back' command");
            callback.onCommandProcessed("Executing back command.");
        } else if (lowerCaseCommand.contains("home")) {
            // Requires Accessibility Service
            Log.d(TAG, "Executing 'home' command");
            callback.onCommandProcessed("Executing home command.");
        } else if (lowerCaseCommand.contains("recent")) {
            // Requires Accessibility Service
            Log.d(TAG, "Executing 'recent' command");
            callback.onCommandProcessed("Executing recent command.");
        } else if (lowerCaseCommand.startsWith("play")) {
            // Media control logic
            Log.d(TAG, "Executing 'play' command");
            callback.onCommandProcessed("Playing.");
        } else if (lowerCaseCommand.startsWith("pause")) {
            // Media control logic
            Log.d(TAG, "Executing 'pause' command");
            callback.onCommandProcessed("Paused.");
        } else {
            // For more complex commands, use the AI Brain
            jarvisBrain.getResponse("Interpret the following command: " + command, new JarvisBrain.BrainCallback() {
                @Override
                public void onSuccess(String response) {
                    // Process the interpreted command from the AI
                    Log.d(TAG, "AI Response: " + response);
                    callback.onCommandProcessed(response);
                }

                @Override
                public void onError(Throwable throwable) {
                    Log.e(TAG, "AI Error: ", throwable);
                    callback.onCommandProcessed("Sorry, I'm having trouble understanding.");
                }
            });
        }
    }

    private String openApp(String command) {
        String appName = command.substring("open".length()).trim();
        if (appName.equalsIgnoreCase("settings")) {
            Intent intent = new Intent(Settings.ACTION_SETTINGS);
            context.startActivity(intent);
            return "Opening Settings";
        } else if (appName.equalsIgnoreCase("camera")) {
            Intent intent = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
            context.startActivity(intent);
            return "Opening Camera";
        }
        PackageManager pm = context.getPackageManager();
        Intent intent = pm.getLaunchIntentForPackage(getAppPackageName(appName));
        if (intent != null) {
            context.startActivity(intent);
            return "Opening " + appName;
        } else {
            Log.e(TAG, "Could not open app: " + appName);
            return "Sorry, I couldn't find the " + appName + " app.";
        }
    }

    private String getAppPackageName(String appName) {
        // This is a simplified mapping. A real implementation would need a more robust way to find package names.
        switch (appName.toLowerCase()) {
            case "gallery":
                return "com.android.gallery3d";
            // Add more app mappings here
            default:
                return null;
        }
    }
}
