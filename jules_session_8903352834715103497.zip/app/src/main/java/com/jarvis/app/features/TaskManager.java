package com.jarvis.app.features;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class TaskManager {

    private static final String SHARED_PREFS_NAME = "JarvisTaskManager";
    private static final String TASKS_KEY = "Tasks";

    private final SharedPreferences sharedPreferences;
    private final Gson gson = new Gson();
    private List<String> tasks;

    public TaskManager(Context context) {
        this.sharedPreferences = context.getSharedPreferences(SHARED_PREFS_NAME, Context.MODE_PRIVATE);
        loadTasks();
    }

    private void loadTasks() {
        String json = sharedPreferences.getString(TASKS_KEY, null);
        if (json != null) {
            Type type = new TypeToken<ArrayList<String>>() {}.getType();
            tasks = gson.fromJson(json, type);
        } else {
            tasks = new ArrayList<>();
        }
    }

    private void saveTasks() {
        String json = gson.toJson(tasks);
        sharedPreferences.edit().putString(TASKS_KEY, json).apply();
    }

    public String addTask(String task) {
        tasks.add(task);
        saveTasks();
        return "Task added: " + task;
    }

    public String showTasks() {
        if (tasks.isEmpty()) {
            return "You have no tasks.";
        }
        StringBuilder taskList = new StringBuilder("Here are your tasks:\n");
        for (int i = 0; i < tasks.size(); i++) {
            taskList.append(i + 1).append(". ").append(tasks.get(i)).append("\n");
        }
        return taskList.toString();
    }
}
