package com.jarvis.app.features;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

public class NotesManager {

    private static final String SHARED_PREFS_NAME = "JarvisNotesManager";
    private static final String NOTES_KEY = "Notes";

    private final SharedPreferences sharedPreferences;
    private final Gson gson = new Gson();
    private Map<String, String> notes;

    public NotesManager(Context context) {
        this.sharedPreferences = context.getSharedPreferences(SHARED_PREFS_NAME, Context.MODE_PRIVATE);
        loadNotes();
    }

    private void loadNotes() {
        String json = sharedPreferences.getString(NOTES_KEY, null);
        if (json != null) {
            Type type = new TypeToken<HashMap<String, String>>() {}.getType();
            notes = gson.fromJson(json, type);
        } else {
            notes = new HashMap<>();
        }
    }

    private void saveNotes() {
        String json = gson.toJson(notes);
        sharedPreferences.edit().putString(NOTES_KEY, json).apply();
    }

    public String createNote(String title, String content) {
        notes.put(title, content);
        saveNotes();
        return "Note created with title: " + title;
    }

    public String showNotes() {
        if (notes.isEmpty()) {
            return "You have no notes.";
        }
        StringBuilder noteList = new StringBuilder("Here are your notes:\n");
        for (Map.Entry<String, String> entry : notes.entrySet()) {
            noteList.append("Title: ").append(entry.getKey()).append("\n");
        }
        return noteList.toString();
    }
}
