package com.jarvis.app.ui;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.jarvis.app.R;
import com.jarvis.app.core.CommandRouter;
import com.jarvis.app.core.JarvisBrain;
import com.jarvis.app.core.SpeechEngine;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class HomeActivity extends AppCompatActivity implements SpeechEngine.SpeechCallback, CommandRouter.CommandCallback {

    private static final int RECORD_AUDIO_PERMISSION_CODE = 1;

    private TextView tvOutput;
    private Button btnListen;

    private SpeechEngine speechEngine;
    private CommandRouter commandRouter;
    private JarvisBrain jarvisBrain;
    private boolean isListening = false;
    private ExecutorService executorService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        tvOutput = findViewById(R.id.tv_output);
        btnListen = findViewById(R.id.btn_listen);

        executorService = Executors.newSingleThreadExecutor();
        jarvisBrain = new JarvisBrain(executorService);
        speechEngine = new SpeechEngine(this, this);
        commandRouter = new CommandRouter(this, jarvisBrain, speechEngine);

        btnListen.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, RECORD_AUDIO_PERMISSION_CODE);
            } else {
                toggleListening();
            }
        });
    }

    private void toggleListening() {
        if (isListening) {
            speechEngine.stopListening();
        } else {
            speechEngine.startListening();
        }
    }

    @Override
    public void onSpeechResult(String result) {
        tvOutput.setText(result);
        commandRouter.routeCommand(result, this);
    }

    @Override
    public void onSpeechError(String errorMessage) {
        tvOutput.setText(errorMessage);
    }

    @Override
    public void onListeningStatusChanged(boolean isListening) {
        this.isListening = isListening;
        btnListen.setText(isListening ? "Stop Listening" : "Listen");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        speechEngine.shutdown();
        if (executorService != null) {
            executorService.shutdown();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == RECORD_AUDIO_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                toggleListening();
            } else {
                tvOutput.setText("Permission to record audio was denied.");
            }
        }
    }

    @Override
    public void onCommandProcessed(String response) {
        tvOutput.setText(response);
        speechEngine.speak(response);
    }
}
